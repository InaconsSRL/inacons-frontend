
const Usuarios: React.FC = () => {
    return (
        <div>
            <h2>Página de Usuarios</h2>
           
        </div>
    );
};

export default Usuarios;
