import RoleManagementTable from "../Role/RoleManagementTable";

const Role: React.FC = () => {
    return (
        <div>
            <h2>Página de Roles</h2>
           
        </div>
    );
};

export default Role;
